package Han;

import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Pairing;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.util.Random;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Properties;
import static java.lang.System.out;

public class Han {
    public static void storePropToFile(Properties prop, String fileName){
        try(FileOutputStream out = new FileOutputStream(fileName)){
            prop.store(out, null);
        }
        catch (IOException e) {
            e.printStackTrace();
            out.println(fileName + " save failed!");
            System.exit(-1);
        }
    }

    public static Properties loadPropFromFile(String fileName) {
        Properties prop = new Properties();
        try (
                FileInputStream in = new FileInputStream(fileName)){
            prop.load(in);
        }
        catch (IOException e){
            e.printStackTrace();
            out.println(fileName + " load failed!");
            System.exit(-1);
        }
        return prop;
    }

    //哈希函数
    public static byte[] sha0(String content) throws NoSuchAlgorithmException {
        MessageDigest instance = MessageDigest.getInstance("SHA-1");
        instance.update(content.getBytes());
        return instance.digest();
    }

    public static String getRandomString(int length) {
        String str = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        Random random = new Random();
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < length; i++) {
            int number = random.nextInt(62);    //从62个字符中随机取其中一个
            sb.append(str.charAt(number));  //用取到的数当索引取字符加到length个数的字符串
        }
        return sb.toString();  //返回字符串
    }

    public static void main(String[] args) throws NoSuchAlgorithmException {
        String dir = "./storeFile/Han_File/"; //根路径
        String pairingFile = dir + "a.properties";
        Pairing bp = PairingFactory.getPairing(pairingFile);
        System.out.println("--------------------------------------------------");

        int n = 50;
        double[] m = new double[n+1];
        double[] f = new double[n+1];
        Element[] vec_m = new Element[n+1];
        Element[] vec_f = new Element[n+1];
        BigInteger M = BigInteger.ZERO;//
        Random rand = new Random();
        String id="User";
        Element ID = bp.getZr().newElementFromBytes(id.getBytes()).getImmutable();
        Element TE = bp.getZr().newRandomElement().getImmutable();

        for (int i = 1; i <= n; i++)
        {
            m[i] = rand.nextInt(30);
            vec_m[i] = bp.getZr().newElement(BigInteger.valueOf((long) m[i])).getImmutable();
            f[i] = rand.nextInt(30);
            vec_f[i] = bp.getZr().newElement(BigInteger.valueOf((long) f[i])).getImmutable();
            M = M.add(BigInteger.valueOf((long) (m[i] * f[i])));
        }
        System.out.println("The dimension of vector is: " + n);
        System.out.println("The value of M is: " + M);//为了后续与内积相关的运算正常
        System.out.println("--------------------------------------------------");

        /*---------------------------------------------------------------------------------------------*/
        long start = System.nanoTime();
        /*Setup----------------------------------------------------------------------------------------*/
        long start_setup = System.nanoTime();
        Element g = bp.getG1().newRandomElement().getImmutable();
        Element g0 = bp.getG1().newRandomElement().getImmutable();
        Element g1 = bp.getG1().newRandomElement().getImmutable();
        Element g2 = bp.getG1().newRandomElement().getImmutable();
        Element g3 = bp.getG1().newRandomElement().getImmutable();
        Element g4 = bp.getG1().newRandomElement().getImmutable();
        Element h = bp.getG2().newRandomElement().getImmutable();
        Element x1 = bp.getZr().newRandomElement().getImmutable();
        Element x2 = bp.getZr().newRandomElement().getImmutable();
        Element e_gh = bp.pairing(g,h).getImmutable();
        Element e_g4h = bp.pairing(g4,h).getImmutable();
        Element[] s = new Element[n+1];
        for (int i = 1; i <= n; i++)
            s[i] = bp.getZr().newRandomElement().getImmutable();
        Element[] X = new Element[4];
        X[0] = e_gh.getImmutable();
        X[1] = h.powZn(x1).getImmutable();
        X[2] = h.powZn(x2).getImmutable();
        X[3] = e_g4h.powZn(x2).getImmutable();
        Element[] Y = new Element[n+1];
        Element g_s = bp.getG1().newOneElement();
        for (int i = 1; i <= n; i++) {
            Y[i] = e_gh.powZn(s[i]).getImmutable();
            g_s = g_s.mul(g.powZn(s[i]));
        }
        g_s = g_s.getImmutable();

        long end_setup = System.nanoTime();
        System.out.println("Setup(1^k,n):Over...");
        /*KGen(msk,HID,f) -> ------------------------------------------------------------------------------*/
        long start_kgen = System.nanoTime();
        Element r = bp.getZr().newRandomElement().getImmutable();
        Element w = bp.getZr().newRandomElement().getImmutable();
        //g^<s,f>
        Element g_sf = bp.getG1().newOneElement();
        for (int i = 1; i <= n; i++) {
            g_sf = g_sf.mul(g_s.powZn(vec_f[i]));
        }
        g_sf = g_sf.getImmutable();

        byte[] hash1 = sha0(ID.toString());
        Element hash_ID = bp.getZr().newElementFromHash(hash1,0,hash1.length).getImmutable();

        Element K1 = g1.mul(g2.powZn(hash_ID)).powZn(x1).mul(g3.powZn(x2)).powZn(r);
        K1 = K1.mul(g_sf).getImmutable();
        Element K2 = X[1].powZn(r).getImmutable();
        Element K3 = X[2].powZn(r).getImmutable();
        Element K4 = h.powZn(r).getImmutable();
        Element K5 = g0.powZn(r).mul(g4.powZn(x2)).getImmutable();

        long end_kgen = System.nanoTime();
        System.out.println("kGen(msk,f,ID):Over...");
        /*Enc(ID,m) -> -----------------------------------------------------------------------------*/
        long start_enc = System.nanoTime();
        Element t = bp.getZr().newRandomElement().getImmutable();
        byte[] hash2 = sha0(TE.toString());
        Element hash_TE = bp.getZr().newElementFromHash(hash2,0,hash2.length).getImmutable();

        Element[] C1 = new Element[6];
        C1[1] = g1.powZn(t).getImmutable();
        C1[2] = g2.powZn(t).getImmutable();
        C1[3] = g3.powZn(t).getImmutable();
        C1[4] = g0.powZn(t).getImmutable();
        C1[5] = h.powZn(t).getImmutable();
        Element[] C2 = new Element[n+1];
        for (int i = 1; i <= n; i++)
            C2[i] = (Y[i].powZn(t)).mul(X[3].powZn(t.mul(hash_TE))).mul(X[0].powZn(vec_m[i])).getImmutable();

        long end_enc = System.nanoTime();
        System.out.println("Enc(m,TE):Over...");
        /*Additional calculations: e(g,g)^<m,f> -> -----------------------------------------------------------------------------*/
        long start_extra = System.nanoTime();

        Element e_m = bp.getGT().newOneElement();
        Element e_mf = bp.getGT().newOneElement();
        for (int i = 1; i <= n; i++)
            e_m = e_m.mul(e_gh.powZn(vec_m[i]));
        e_m = e_m.getImmutable();
        for (int i = 1; i <= n; i++) {
            e_mf = e_mf.mul(e_m.powZn(vec_f[i]));
        }
        e_mf = e_mf.getImmutable();

        long end_extra = System.nanoTime();
        System.out.println("Additional calculations time cost: " + ((end_extra - start_extra)/1000000.0) + " ms");
        /*Dec(CT,sk) -> ---------------------------------------------------------------------------------*/
        long start_dec = System.nanoTime();

        Element e1 = bp.getGT().newOneElement();
        Element e2 = e_g4h.powZn(x2).powZn(t).powZn(hash_TE).getImmutable();
        Element e3 = bp.getGT().newOneElement();
        Element e1_f = bp.getGT().newOneElement();
        Element e2_f = bp.getGT().newOneElement();
        Element e3_f = bp.getGT().newOneElement();
        Element e_gh_t = e_gh.powZn(t).getImmutable();
        for (int i = 1; i <= n; i++) {
            e1 = e1.mul(e_gh_t.powZn(s[i]));
            e3 = e3.mul(e_gh.powZn(vec_m[i]));
        }
        e1 = e1.getImmutable(); e2 = e2.getImmutable(); e3 = e3.getImmutable();
        for (int i = 1; i <= n; i++) {
            e1_f = e1_f.mul(e1.powZn(vec_f[i]));
            e2_f = e2_f.mul(e2.powZn(vec_f[i]));
            e3_f = e3_f.mul(e3.powZn(vec_f[i]));
        }
        e1_f = e1_f.getImmutable(); e2_f = e2_f.getImmutable(); e3_f = e3_f.getImmutable();

        Element C2_f = bp.getGT().newOneElement();
        for (int i = 1; i <= n; i++) {
            C2_f = C2_f.mul(C2[i].powZn(vec_f[i]));
        }
        C2_f = C2_f.getImmutable();

        Element e_c1k2 = bp.pairing(C1[1],K2).getImmutable();
        Element e_c2k2 = bp.pairing(C1[2],K2).powZn(hash_ID).getImmutable();
        Element e_c3k3 = bp.pairing(C1[3],K3).getImmutable();
        Element e_c4k4 = bp.pairing(C1[4],K4).getImmutable();
        Element e_c4k4_f = bp.getGT().newOneElement();
        for (int i = 1; i <= n; i++)
            e_c4k4_f = e_c4k4_f.mul(e_c4k4.powZn(hash_TE).powZn(vec_f[i]));
        e_c4k4_f = e_c4k4_f.getImmutable();
        Element e_k1c5 = bp.pairing(K1,C1[5]).getImmutable();
        Element e_k5c5 = bp.pairing(K5,C1[5]).getImmutable();
        Element e_c5k5_tf = bp.getGT().newOneElement();
        for (int i = 1; i <= n; i++)
            e_c5k5_tf = e_c5k5_tf.mul(e_k5c5.powZn(hash_TE).powZn(vec_f[i]));
        e_c5k5_tf = e_c5k5_tf.getImmutable();

        Element dec_res =e1_f.mul(e2_f).mul(e3_f).mul(e_c1k2).mul(e_c2k2).mul(e_c3k3).mul(e_c4k4_f).div(e_k1c5).div(e_c5k5_tf).getImmutable();

        if (dec_res.isEqual(e_mf))
            System.out.println("Dec(SK,CT) -> succeeded!");
        else
            System.out.println("Dec(SK,CT) -> failed!");

        long end_dec = System.nanoTime();
        System.out.println("Dec(SK,CT):Over...");
        /*---------------------------------------------------------------------------------------------*/
        long end = System.nanoTime();
        System.out.println("--------------------------------------------------");
        /*---------------------------------------------------------------------------------------------*/
        /*<time cost>-----------------------------------------------------------------------------------*/
        System.out.println("Setup algorithm time cost: " + ((end_setup - start_setup)/1000000.0) + " ms");
        System.out.println("Enc algorithm time cost: " + ((end_enc - start_enc)/1000000.0) + " ms");
        System.out.println("KGen algorithm time cost: " + ((end_kgen - start_kgen)/1000000.0) + " ms");
        System.out.println("Dec algorithm time cost: " + ((end_dec - start_dec)/1000000.0) + " ms");
        System.out.println("Total time cost: " + ((end - start)/1000000.0) + " ms");
        System.out.println("--------------------------------------------------");
    }
}

package Ours;

import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Pairing;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.file.Paths;
import java.nio.file.Files;
import java.util.Random;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Properties;
import static java.lang.System.out;
import it.unisa.dia.gas.plaf.jpbc.pairing.a1.TypeA1CurveGenerator;
import it.unisa.dia.gas.jpbc.PairingParameters;
import it.unisa.dia.gas.plaf.jpbc.util.ElementUtils;

public class Ours {
    public static void storePropToFile(Properties prop, String fileName){
        try(FileOutputStream out = new FileOutputStream(fileName)){
            prop.store(out, null);
        }
        catch (IOException e) {
            e.printStackTrace();
            out.println(fileName + " save failed!");
            System.exit(-1);
        }
    }

    public static Properties loadPropFromFile(String fileName) {
        Properties prop = new Properties();
        try (
                FileInputStream in = new FileInputStream(fileName)){
            prop.load(in);
        }
        catch (IOException e){
            e.printStackTrace();
            out.println(fileName + " load failed!");
            System.exit(-1);
        }
        return prop;
    }

    //哈希函数
    public static byte[] sha0(String content) throws NoSuchAlgorithmException {
        MessageDigest instance = MessageDigest.getInstance("SHA-1");
        instance.update(content.getBytes());
        return instance.digest();
    }

    public static void IBIPFEET(int n) {

    }

    public static void main(String[] args) throws NoSuchAlgorithmException {
        // 指定质数数量和每个质数的比特长度
        int numPrimes = 3; // 3个质数
        int bitLength = 120; // 每个质数的比特长度
        // 使用TypeA1CurveGenerator生成配对参数
        TypeA1CurveGenerator generator = new TypeA1CurveGenerator(numPrimes, bitLength);
        PairingParameters typeA1Params = generator.generate();
        Pairing bp = PairingFactory.getPairing(typeA1Params);

        // 指定输出目录和文件名
        String dir = "./storeFile/Ours_File/";
        String fileName = "a1.properties";
        String filePath = Paths.get(dir, fileName).toString();

        // 确保目录存在
        try {
            Files.createDirectories(Paths.get(dir));
        } catch (IOException e) {
            e.printStackTrace();
            return; // 目录创建失败，退出程序
        }

        // 将生成的参数写入文件
        try (FileOutputStream out = new FileOutputStream(filePath)) {
            // 使用params.toString()方法获取配置参数并写入文件
            out.write(typeA1Params.toString().getBytes());
            out.flush();
            System.out.println("File written successfully to " + filePath);
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("--------------------------------------------------");

        int n = 10;
        String ID1 = "User1";
        String ID2 = "User2";
        Element ID_1 = bp.getZr().newElementFromBytes(ID1.getBytes()).getImmutable();
        Element ID_2 = bp.getZr().newElementFromBytes(ID2.getBytes()).getImmutable();
        double[] x = new double[n];
        double[] y1 = new double[n];
        double[] y2 = new double[n];
        Element[] vec_x = new Element[n];
        Element[] vec_y1 = new Element[n];
        Element[] vec_y2 = new Element[n];
        BigInteger M = BigInteger.ZERO;//
        Random rand = new Random();
        for (int i = 0; i < n; i++)
        {
            x[i] = rand.nextInt(1000);
            vec_x[i] = bp.getZr().newElement(BigInteger.valueOf((long) x[i])).getImmutable();
            y1[i] = rand.nextInt(1000);
            vec_y1[i] = bp.getZr().newElement(BigInteger.valueOf((long) y1[i])).getImmutable();
            y2[i] = rand.nextInt(1000);
            vec_y2[i] = bp.getZr().newElement(BigInteger.valueOf((long) y2[i])).getImmutable();
            M = M.add(BigInteger.valueOf((long) (x[i] * y1[i])));
        }
        System.out.println("The dimension of vector is: " + n);
        System.out.println("The value of M is: " + M);//为了后续与内积相关的运算正常
        System.out.println("--------------------------------------------------");

        /*---------------------------------------------------------------------------------------------*/
        long start = System.nanoTime();
        /*Setup----------------------------------------------------------------------------------------*/
        long start_setup = System.nanoTime();
        Element alpha = bp.getZr().newRandomElement().getImmutable();//从Z_N上任选一个数
        Element beta = bp.getZr().newRandomElement().getImmutable();//从Z_N上任选一个数
        //随机产生G_p_1(G1)中的元素
        Element G = bp.getG1().newRandomElement().getImmutable();
        Element u = ElementUtils.getGenerator(bp, G, typeA1Params, 0, 3).getImmutable();
        Element h = ElementUtils.getGenerator(bp, G, typeA1Params, 0, 3).getImmutable();
        Element g = ElementUtils.getGenerator(bp, G, typeA1Params, 0, 3).getImmutable();
        //随机产生G_p_3(G3)中的元素
        Element X3 = ElementUtils.getGenerator(bp, G, typeA1Params, 2, 3).getImmutable();
        Element e_gg = bp.pairing(g,g).getImmutable();
        Element e_gg_alpha = e_gg.powZn(alpha).getImmutable();
        Element e_gg_beta = e_gg.powZn(beta).getImmutable();
        Element g_alpha = g.powZn(alpha.negate()).getImmutable();
        Element g_beta = g.powZn(beta.negate()).getImmutable();
//        System.out.println("u:"+u);
//        System.out.println("h:"+h);
//        System.out.println("g:"+g);
//        System.out.println("X3:"+X3);
//        System.out.println("alpha:"+alpha);
//        System.out.println("beta:"+beta);
//        System.out.println("e_gg_alpha:"+e_gg_alpha);
//        System.out.println("e_gg_beta:"+e_gg_beta);

        long end_setup = System.nanoTime();
        System.out.println("Setup(1^k,n):Over...");
        /*Enc(ID1,x) -> -----------------------------------------------------------------------------*/
        long start_enc = System.nanoTime();

        Element s_1 = bp.getZr().newRandomElement().getImmutable();//从Z_N上任选一个数
        byte[] hash1 =sha0(e_gg_beta.powZn(s_1).toString());
        Element e_gg_hash1 = bp.getG1().newElementFromHash(hash1,0,hash1.length).getImmutable();
        Element uh_1 = u.powZn(ID_1).mul(h).getImmutable();
        Element C0_1 = bp.getGT().newOneElement();
        Element C1_1 = g.powZn(s_1).getImmutable();
        Element C2_1 = uh_1.powZn(s_1).getImmutable();
        Element C3_1 = bp.getG1().newOneElement();
        Element u_s1 = u.powZn(s_1).getImmutable();
        Element e_ug = bp.pairing(u,g).getImmutable();

        for (int i = 0; i < n; i++) {
            C0_1 = C0_1.mul(e_ug.powZn(vec_x[i]));
            C3_1 = C3_1.mul(u_s1.powZn(vec_x[i]));
        }
        C0_1 = C0_1.mul(e_gg_alpha.powZn(s_1)).getImmutable();
        C3_1 = C3_1.mul(e_gg_hash1).getImmutable();

        long end_enc = System.nanoTime();
        System.out.println("Enc(ID1,x):Over...");
        /*KGen(msk,ID1,y1) -> ------------------------------------------------------------------------------*/
        long start_kgen = System.nanoTime();

        Element r1_1 = bp.getZr().newRandomElement().getImmutable();//从Z_N上任选一个数
        Element r2_1 = bp.getZr().newRandomElement().getImmutable();//从Z_N上任选一个数
        Element mu1_1 = bp.getZr().newRandomElement().getImmutable();//从Z_N上任选一个数
        Element mu2_1 = bp.getZr().newRandomElement().getImmutable();//从Z_N上任选一个数
        Element X3_mu1_1 = X3.powZn(mu1_1).getImmutable();
        Element X3_mu2_1 = X3.powZn(mu2_1).getImmutable();
        Element uh_1_r1_1 = uh_1.powZn(r1_1).getImmutable();
        Element uh_1_r2_1 = uh_1.powZn(r2_1).getImmutable();

        Element d1_1 = bp.getG1().newOneElement();
        Element d2_1 = g.powZn(r1_1.negate()).mul(X3_mu2_1);
        Element d3_1 = g_beta.mul(uh_1_r2_1).mul(X3_mu1_1);
        Element d4_1 = g.powZn(r2_1.negate()).mul(X3_mu2_1);

        for (int i = 0; i < n; i++) {
            d1_1 = d1_1.mul(g_alpha.powZn(vec_y1[i]));
        }
        d1_1 = d1_1.mul(uh_1_r1_1).mul(X3_mu1_1);

        long end_kgen = System.nanoTime();
        System.out.println("kGen(msk,ID1,y1):Over...");

        /*Additional calculations: e(u,g)^<x,y> -> ----------------------------------------------------------------------*/
        long start_extra = System.nanoTime();

        Element e_x = bp.getGT().newOneElement();
        Element e_xy = bp.getGT().newOneElement();
        for (int i = 0; i < n; i++) {
            e_x = e_x.mul(e_ug.powZn(vec_x[i]));
        }
        e_x = e_x.getImmutable();
        for (int i = 0; i < n; i++) {
            e_xy = e_xy.mul(e_x.powZn(vec_y1[i]));
        }
        e_xy = e_xy.getImmutable();

        long end_extra = System.nanoTime();
        /*Dec(CT1,sk1) -> ---------------------------------------------------------------------------------*/
        long start_dec = System.nanoTime();

        Element e_d1C1_1 = bp.pairing(d1_1,C1_1).getImmutable();
        Element e_d2C2_1 = bp.pairing(d2_1,C2_1).getImmutable();
        Element w_1 = e_d1C1_1.mul(e_d2C2_1).getImmutable();
        Element C0Y_1 = bp.getGT().newOneElement();
        for (int i = 0; i < n; i++) {
            C0Y_1 = C0Y_1.mul(C0_1.powZn(vec_y1[i]));
        }
        C0Y_1 = C0Y_1.getImmutable();
        Element C0Yw_1 = C0Y_1.mul(w_1).getImmutable();

        if (C0Yw_1.isEqual(e_xy))
            System.out.println("Dec(CT1,sk1) -> succeeded!");
        else
            System.out.println("Dec(CT1,sk1) -> failed!");

        long end_dec = System.nanoTime();
        System.out.println("Dec(CT1,sk1):Over...");
        /*Trapdoor(CT1,sk1) -> ----------------------------------------------------------------------------------*/
        long start_td = System.nanoTime();

        Element e_d3C1_1 = bp.pairing(d3_1,C1_1).getImmutable();
        Element e_d4C2_1 = bp.pairing(d4_1,C2_1).getImmutable();
        Element td_1 = e_d3C1_1.mul(e_d4C2_1).getImmutable();

        long end_td = System.nanoTime();
        System.out.println("Trapdoor(CT1,sk1):Over...");
        /*---------------------------------------------------------------------------------------------*/
        long end = System.nanoTime();
        System.out.println("--------------------------------------------------");
        /*---------------------------------------------------------------------------------------------*/
        /*Test(CT1,td1,CT2,td2) -> ---------------------------------------------------------------------------------------*/
        /*
            1.用ID2加密x -> CT2；
            2.生成ID2的私钥 -> sk2
            3.生成ID2的trapdoor -> td2；
            4.执行Test算法，在不解密的情况下判断CT1与CT2是否加密同一个数据 -> true/false
         */
        /*Enc(ID2,x) -> */
        Element s_2 = bp.getZr().newRandomElement().getImmutable();//从Z_N上任选一个数

        byte[] hash2 =sha0(e_gg_beta.powZn(s_2).toString());
        Element e_gg_hash2 = bp.getG1().newElementFromHash(hash2,0,hash2.length).getImmutable();
        Element uh_2 = u.powZn(ID_2).mul(h);
        Element C0_2 = bp.getGT().newOneElement();
        Element C1_2 = g.powZn(s_2);
        Element C2_2 = uh_2.powZn(s_2);
        Element C3_2 = bp.getG1().newOneElement();

        for (int i = 0; i < n; i++)
        {
            C0_2 = C0_2.mul(bp.pairing(u,g).powZn(vec_x[i]));
            C3_2 = C3_2.mul(u.powZn(s_2).powZn(vec_x[i]));
        }
        C0_2 = C0_2.mul(e_gg_alpha.powZn(s_2));
        C3_2 = C3_2.mul(e_gg_hash2);
        System.out.println("Enc(ID2,x):Over...");

        /*KGen(msk,ID2,y2) -> */
        Element r1_2 = bp.getZr().newRandomElement().getImmutable();//从Z_N上任选一个数
        Element r2_2 = bp.getZr().newRandomElement().getImmutable();//从Z_N上任选一个数
        Element mu1_2 = bp.getZr().newRandomElement().getImmutable();//从Z_N上任选一个数
        Element mu2_2 = bp.getZr().newRandomElement().getImmutable();//从Z_N上任选一个数
        Element X3_mu1_2 = X3.powZn(mu1_2).getImmutable();
        Element X3_mu2_2 = X3.powZn(mu2_2).getImmutable();
        Element uh_2_r1_2 = uh_2.powZn(r1_2).getImmutable();
        Element uh_2_r2_2 = uh_2.powZn(r2_2).getImmutable();

        Element d1_2 = bp.getG1().newOneElement();
        Element d2_2 = g.powZn(r1_2.negate()).mul(X3_mu2_2);
        Element d3_2 = g_beta.mul(uh_2_r2_2).mul(X3_mu1_2);
        Element d4_2 = g.powZn(r2_2.negate()).mul(X3_mu2_2);
        for (int i = 0; i < n; i++) {
            d1_2 = d1_2.mul(g_alpha.powZn(vec_y2[i]));
        }
        d1_2 = d1_2.mul(uh_2_r1_2).mul(X3_mu1_2);
        System.out.println("kGen(msk,ID2,y2):Over...");

        /*Trapdoor(sk2,CT2) -> */
        Element e_d3C1_2 = bp.pairing(d3_2,C1_2).getImmutable();
        Element e_d4C2_2 = bp.pairing(d4_2,C2_2).getImmutable();
        Element td_2 = e_d3C1_2.mul(e_d4C2_2).getImmutable();
        System.out.println("Trapdoor(CT2,sk2):Over...");

        /*Test(CT1,td1,CT2,td2) -> */
        long start_test = System.nanoTime();

        byte[] hash_td1 =sha0(td_1.toString());
        Element td1_hash = bp.getG1().newElementFromHash(hash_td1,0,hash_td1.length).getImmutable();
        byte[] hash_td2 =sha0(td_2.toString());
        Element td2_hash = bp.getG1().newElementFromHash(hash_td2,0,hash_td2.length).getImmutable();
        Element us_1 = u.powZn(s_1).getImmutable();
        Element us_2 = u.powZn(s_2).getImmutable();

        Element T1 = bp.getG1().newOneElement();
        Element T2 = bp.getG1().newOneElement();
        for (int i = 0; i < n; i++)
        {
            T1 = T1.mul(us_1.powZn(vec_x[i]));
            T2 = T2.mul(us_2.powZn(vec_x[i]));
        }

        Element e_C1_1T2 = bp.pairing(C1_1, T2).getImmutable();
        Element e_C1_2T1 = bp.pairing(C1_2, T1).getImmutable();

        if (e_C1_1T2.isEqual(e_C1_2T1))
            System.out.println("Test(CT1,td1,CT2,td2) -> 1(equal!)");
        else
            System.out.println("Test(CT1,td1,CT2,td2) -> 0(unequal!)");

        long end_test = System.nanoTime();
        System.out.println("Test(CT1,td1,CT2,td2):Over...");
        System.out.println("--------------------------------------------------");

        /*<time cost>-----------------------------------------------------------------------------------*/
        System.out.println("Setup algorithm time cost: " + ((end_setup - start_setup)/1000000.0) + " ms");
        System.out.println("Enc algorithm time cost: " + ((end_enc - start_enc)/1000000.0) + " ms");
        System.out.println("KGen algorithm time cost: " + ((end_kgen - start_kgen)/1000000.0) + " ms");
        System.out.println("Dec algorithm time cost: " + ((end_dec - start_dec)/1000000.0) + " ms");
//        System.out.println("4个算法-Total time cost: " + (((end - start)-(end_td - start_td))/1000000.0) + " ms");
        System.out.println("Trapdoor algorithm time cost: " + ((end_td - start_td)/1000000.0) + " ms");
        System.out.println("Total time cost: " + ((end - start)/1000000.0) + " ms");
        System.out.println("--------------------------------------------------");
        System.out.println("Test algorithm time cost: " + ((end_test - start_test)/1000000.0) + " ms");
        System.out.println("--------------------------------------------------");

        /*<test the project>---------------------------------------------------------------------------*/
        // 获取子群的阶数
        BigInteger p1 = typeA1Params.getBigInteger("n1"); // 第一个子群的阶数
        BigInteger p2 = typeA1Params.getBigInteger("n1"); // 第二个子群的阶数
        BigInteger p3 = typeA1Params.getBigInteger("n2"); // 第三个子群的阶数

        // 计算并打印子群的比特长度
        System.out.println("阶数 p1 的比特长度: " + p1.bitLength());
        System.out.println("阶数 p2 的比特长度: " + p2.bitLength());
        System.out.println("阶数 p3 的比特长度: " + p3.bitLength());
        System.out.println("--------------------------------------------------");
    }
}

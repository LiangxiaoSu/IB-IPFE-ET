package Song;

import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Pairing;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.util.Random;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Properties;
import static java.lang.System.out;

public class Song {
    public static void storePropToFile(Properties prop, String fileName){
        try(FileOutputStream out = new FileOutputStream(fileName)){
            prop.store(out, null);
        }
        catch (IOException e) {
            e.printStackTrace();
            out.println(fileName + " save failed!");
            System.exit(-1);
        }
    }

    public static Properties loadPropFromFile(String fileName) {
        Properties prop = new Properties();
        try (
                FileInputStream in = new FileInputStream(fileName)){
            prop.load(in);
        }
        catch (IOException e){
            e.printStackTrace();
            out.println(fileName + " load failed!");
            System.exit(-1);
        }
        return prop;
    }

    //哈希函数
    public static byte[] sha0(String content) throws NoSuchAlgorithmException {
        MessageDigest instance = MessageDigest.getInstance("SHA-1");
        instance.update(content.getBytes());
        return instance.digest();
    }

    public static String getRandomString(int length) {
        String str = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        Random random = new Random();
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < length; i++) {
            int number = random.nextInt(62);    //从62个字符中随机取其中一个
            sb.append(str.charAt(number));  //用取到的数当索引取字符加到length个数的字符串
        }
        return sb.toString();  //返回字符串
    }

    public static void main(String[] args) throws NoSuchAlgorithmException {
        String dir = "./storeFile/Song_File/"; //根路径
        String pairingFile = dir + "a.properties";
        Pairing bp = PairingFactory.getPairing(pairingFile);
        System.out.println("--------------------------------------------------");

        int n = 50;
        int d = 50, l = 25;
        double[] id = new double[l+1];
        double[] x = new double[n+1];
        double[] y = new double[n+1];
        Element[] vec_hid = new Element[l+1];
        Element[] vec_x = new Element[n+1];
        Element[] vec_y = new Element[n+1];
        BigInteger M = BigInteger.ZERO;//
        Random rand = new Random();
        for (int i = 1; i <= l; i++) {
            id[i] = rand.nextInt(10);
            vec_hid[i] = bp.getZr().newElement(BigInteger.valueOf((long) id[i])).getImmutable();
        }
        for (int i = 1; i <= n; i++)
        {
            x[i] = rand.nextInt(30);
            vec_x[i] = bp.getZr().newElement(BigInteger.valueOf((long) x[i])).getImmutable();
            y[i] = rand.nextInt(30);
            vec_y[i] = bp.getZr().newElement(BigInteger.valueOf((long) y[i])).getImmutable();
            M = M.add(BigInteger.valueOf((long) (x[i] * y[i])));
        }
        System.out.println("The dimension of vector is: " + n);
        System.out.println("The value of M is: " + M);//为了后续与内积相关的运算正常
        System.out.println("--------------------------------------------------");

        /*---------------------------------------------------------------------------------------------*/
        long start = System.nanoTime();
        /*Setup----------------------------------------------------------------------------------------*/
        long start_setup = System.nanoTime();
        Element g = bp.getG1().newRandomElement().getImmutable();
        Element alpha = bp.getZr().newRandomElement().getImmutable();
        Element g_alpha = g.powZn(alpha).getImmutable();
        Element e_gg = bp.pairing(g,g).getImmutable();

        Element[] u = new Element[d+1+1];
        Element[] h = new Element[n+1];
        for (int i = 1; i <= d+1; i++)
            u[i] = bp.getG1().newRandomElement().getImmutable();
        for (int i = 1; i <= n; i++)
            h[i] = bp.getG1().newRandomElement().getImmutable();

        long end_setup = System.nanoTime();
        System.out.println("Setup(1^k,n):Over...");
        /*KGen(msk,HID,y) -> ------------------------------------------------------------------------------*/
        long start_kgen = System.nanoTime();
        Element t = bp.getZr().newRandomElement().getImmutable();

        Element K_u = u[d+1];
        for (int i = 1; i <= l; i++) {
            K_u = K_u.mul(u[i].powZn(vec_hid[i]));
        }
        K_u = K_u.powZn(t.negate()).getImmutable();

        Element K_h = bp.getG1().newOneElement();
        for (int i = 1; i <= n; i++) {
            K_h = K_h.mul(h[i].powZn(vec_y[i]));
        }
        K_h = K_h.powZn(alpha).mul(K_u).getImmutable();

        Element K_t = g.powZn(t).getImmutable();

        Element[] K = new Element[d+1];
        for (int i = l+1; i <= d; i++) {
            K[i] = u[i].powZn(t).getImmutable();
        }

        long end_kgen = System.nanoTime();
        System.out.println("kGen(msk,HID,y):Over...");
        /*Additional calculations: e(g,g)^<x,y> -> ----------------------------------------------------------------------*/
        long start_extra = System.nanoTime();

        Element e_x = bp.getGT().newOneElement();
        Element e_xy = bp.getGT().newOneElement();
        for (int i = 1; i <= n; i++) {
            e_x = e_x.mul(e_gg.powZn(vec_x[i]));
        }
        e_x = e_x.getImmutable();
        for (int i = 1; i <= n; i++) {
            e_xy = e_xy.mul(e_x.powZn(vec_y[i]));
        }
        e_xy = e_xy.getImmutable();

        long end_extra = System.nanoTime();
        System.out.println("Additional calculations time cost: " + ((end_extra - start_extra)/1000000.0) + " ms");
        /*Enc(HID,x) -> -----------------------------------------------------------------------------*/
        long start_enc = System.nanoTime();
        Element r = bp.getZr().newRandomElement().getImmutable();

        Element[] C_x = new Element[n+1];
        for (int i = 1; i <= n; i++) {
            C_x[i] = e_gg.powZn(vec_x[i]).mul(bp.pairing(g_alpha,h[i]).powZn(r)).getImmutable();
        }
        Element C_r = g.powZn(r).getImmutable();
        Element C_u = u[d+1];
        for (int i = 1; i <= l; i++) {
            C_u = C_u.mul(u[i].powZn(vec_hid[i]));
        }
        C_u = C_u.powZn(r).getImmutable();

        long end_enc = System.nanoTime();
        System.out.println("Enc(HID,x):Over...");
        /*Dec(CT,sk) -> ---------------------------------------------------------------------------------*/
        long start_dec = System.nanoTime();
        //dec...
        Element C_xy = e_xy;
        for(int i = 1; i <= n; i++)
            C_xy = C_xy.mul(bp.pairing(g_alpha,h[i]).powZn(r.mul(vec_y[i])));
        C_xy = C_xy.getImmutable();
        Element e_CrKh = bp.pairing(C_r, K_h).getImmutable();
        Element e_CuKt = bp.pairing(C_u, K_t).getImmutable();
        Element dec_res = C_xy.div(e_CrKh).div(e_CuKt);

        if (dec_res.isEqual(e_xy))
            System.out.println("Dec(CT,sk) -> succeeded!");
        else
            System.out.println("Dec(CT,sk) -> failed!");

        long end_dec = System.nanoTime();
        System.out.println("Dec(CT,sk):Over...");
        /*---------------------------------------------------------------------------------------------*/
        long end = System.nanoTime();
        System.out.println("--------------------------------------------------");
        /*---------------------------------------------------------------------------------------------*/
        /*<time cost>-----------------------------------------------------------------------------------*/
        System.out.println("Setup algorithm time cost: " + ((end_setup - start_setup)/1000000.0) + " ms");
        System.out.println("Enc algorithm time cost: " + ((end_enc - start_enc)/1000000.0) + " ms");
        System.out.println("KGen algorithm time cost: " + ((end_kgen - start_kgen)/1000000.0) + " ms");
        System.out.println("Dec algorithm time cost: " + ((end_dec - start_dec)/1000000.0) + " ms");
        System.out.println("Total time cost: " + ((end - start)/1000000.0) + " ms");
        System.out.println("--------------------------------------------------");
    }
}
